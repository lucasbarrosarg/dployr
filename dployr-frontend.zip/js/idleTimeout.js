﻿let state = {
    dotnet: null,
    timeoutMs: 15 * 60 * 1000, // default 15 min
    warnMs: 60 * 1000,         // warn 60s before timeout
    lastActive: Date.now(),
    warned: false,
    checkHandle: null,
    onActivity: null
};

function markActive() {
    state.lastActive = Date.now();
    if (state.warned) {
        state.warned = false;
        if (state.dotnet) state.dotnet.invokeMethodAsync('OnIdleWarningCleared');
        //console.log('[idle] activity detected; warning cleared');
    } else {
        //console.log('[idle] activity detected');
    }
}

export function register(dotnetRef, timeoutMs, warnMs) {
    unregister();

    state.dotnet = dotnetRef;
    state.timeoutMs = Number(timeoutMs) > 0 ? Number(timeoutMs) : state.timeoutMs;
    state.warnMs = Number(warnMs) > 0 ? Number(warnMs) : state.warnMs;
    state.lastActive = Date.now();
    state.warned = false;

    state.onActivity = () => markActive();

    window.addEventListener('mousemove', state.onActivity, true);
    window.addEventListener('mousedown', state.onActivity, true);
    window.addEventListener('keydown', state.onActivity, true);
    window.addEventListener('touchstart', state.onActivity, true);
    window.addEventListener('scroll', state.onActivity, true);
    document.addEventListener('visibilitychange', () => {
        if (!document.hidden) markActive();
    }, true);

    state.checkHandle = setInterval(() => {
        const now = Date.now();
        const elapsed = now - state.lastActive;

        if (!state.warned && elapsed >= (state.timeoutMs - state.warnMs)) {
            state.warned = true;
            //console.log('[idle] warning threshold reached');
            if (state.dotnet) state.dotnet.invokeMethodAsync('OnIdleWarning');
        }

        if (elapsed >= state.timeoutMs) {
            //console.log('[idle] timeout reached -> sign out');
            if (state.dotnet) state.dotnet.invokeMethodAsync('OnIdleTimeout');
        }
    }, 1000);

    //console.log('[idle] registered', { timeoutMs: state.timeoutMs, warnMs: state.warnMs });
}

export function unregister() {
    if (state.checkHandle) {
        clearInterval(state.checkHandle);
        state.checkHandle = null;
    }
    if (state.onActivity) {
        window.removeEventListener('mousemove', state.onActivity, true);
        window.removeEventListener('mousedown', state.onActivity, true);
        window.removeEventListener('keydown', state.onActivity, true);
        window.removeEventListener('touchstart', state.onActivity, true);
        window.removeEventListener('scroll', state.onActivity, true);
        state.onActivity = null;
    }
    state.dotnet = null;
    state.warned = false;
    //console.log('[idle] unregistered');
}