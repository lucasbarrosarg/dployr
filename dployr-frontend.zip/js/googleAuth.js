﻿window.googleAuth = (function () {
    let initialized = false;
    let lastClientId = null;
    let retryCount = 0;
    const maxRetries = 5;

    let lastBtnWidth = null;
    let resizeHandler = null;
    let viewportResizeHandler = null;

    let shownOnce = false;
    let iframeObserver = null;
    let iframeReadyTimer = null;

    let currentLocale = null;
    const MIN_WIDTH_CHANGE = 16;

    // Nueva referencia global a .NET para re-init
    let dotNetRefGlobal = null;

    // Forzar render ignorando MIN_WIDTH_CHANGE
    let forceNextRender = false;

    function log(...a) { console.log("[googleAuth]", ...a); }
    function warn(...a) { console.warn("[googleAuth]", ...a); }
    function err(...a) { console.error("[googleAuth]", ...a); }

    function resolveLocale(explicitLocale) {
        const lc =
            explicitLocale ||
            window.BlazorCulture ||
            localStorage.getItem("blazor-culture") ||
            document.documentElement.lang ||
            navigator.language ||
            "en";
        return String(lc).replace("_", "-");
    }

    function safeDisable() {
        try {
            if (window.google?.accounts?.id) {
                if (google.accounts.id.cancel) google.accounts.id.cancel();
                if (google.accounts.id.disableAutoSelect) google.accounts.id.disableAutoSelect();
            }
        } catch { }
    }

    function revokePrevious() {
        try {
            const prevEmail = localStorage.getItem("google_last_email");
            if (prevEmail && window.google?.accounts?.id?.revoke) {
                google.accounts.id.revoke(prevEmail, done => log("revoked previous", prevEmail, done));
            }
        } catch { }
    }

    function markEmailFromCredential(credential) {
        try {
            const mid = credential.split(".")[1];
            const json = atob(mid.replace(/-/g, "+").replace(/_/g, "/"));
            const payload = JSON.parse(json);
            if (payload?.email) {
                localStorage.setItem("google_last_email", payload.email);
            }
        } catch { }
    }

    function getAvailableWidth(host) {
        if (!host) return 0;
        const container = host.parentElement || host;
        const w = Math.floor(container.clientWidth || container.getBoundingClientRect().width || 0);
        return Math.max(240, w);
    }

    function ensureVisibleWhenIframeReady(host) {
        if (shownOnce) {
            if (!host.classList.contains("ready")) host.classList.add("ready");
            host.style.visibility = "visible";
            return;
        }
        try { if (iframeObserver) { iframeObserver.disconnect(); iframeObserver = null; } } catch { }
        clearTimeout(iframeReadyTimer);

        const show = () => {
            if (shownOnce) return;
            shownOnce = true;
            host.style.visibility = "visible";
            host.classList.add("ready");
            try { if (iframeObserver) { iframeObserver.disconnect(); iframeObserver = null; } } catch { }
            clearTimeout(iframeReadyTimer);
            log("GIS iframe ready -> show button");
        };

        const currentIframe = host.querySelector("iframe");
        if (currentIframe) {
            currentIframe.addEventListener("load", show, { once: true });
            iframeReadyTimer = setTimeout(show, 1000);
            return;
        }

        if (window.MutationObserver) {
            iframeObserver = new MutationObserver((mutations) => {
                for (const m of mutations) {
                    for (const n of m.addedNodes) {
                        if (n.tagName === "IFRAME") {
                            n.addEventListener("load", show, { once: true });
                            iframeReadyTimer = setTimeout(show, 1000);
                            return;
                        }
                    }
                }
            });
            iframeObserver.observe(host, { childList: true, subtree: true });
        }

        iframeReadyTimer = setTimeout(show, 1200);
    }

    function renderButton(host, width) {
        if (!host || !window.google?.accounts?.id?.renderButton) return;

        if (!forceNextRender && lastBtnWidth !== null && Math.abs(width - lastBtnWidth) < MIN_WIDTH_CHANGE) {
            return;
        }
        forceNextRender = false;

        lastBtnWidth = width;
        host.innerHTML = "";

        if (!shownOnce) {
            host.style.visibility = "hidden";
            host.classList.remove("ready");
        }

        google.accounts.id.renderButton(host, {
            theme: "outline",
            size: "large",
            type: "standard",
            shape: "rectangular",
            text: "signin_with",
            width,
            locale: currentLocale
        });

        ensureVisibleWhenIframeReady(host);
        log("Botón renderizado con width:", width, "locale:", currentLocale);
    }

    async function firstStableRender(host) {
        try { await (document.fonts?.ready ?? Promise.resolve()); } catch { }
        await new Promise(r => requestAnimationFrame(() => requestAnimationFrame(r)));
        const w = getAvailableWidth(host);
        renderButton(host, w);
    }

    function wireResize(host) {
        const onResize = () => {
            if (!document.body.contains(host)) return;
            const w = getAvailableWidth(host);
            renderButton(host, w);
        };
        resizeHandler = onResize;
        window.addEventListener("resize", resizeHandler, { passive: true });
        if (window.visualViewport) {
            viewportResizeHandler = onResize;
            window.visualViewport.addEventListener("resize", viewportResizeHandler, { passive: true });
        }
    }

    function forceRefresh() {
        const host = document.getElementById("googleSignInBtn");
        if (!host) return;
        const w = getAvailableWidth(host);
        forceNextRender = true;
        renderButton(host, w);
    }

    function init(clientId, dotNetRef, locale) {
        try {
            if (!clientId) { err("ClientId vacío"); return; }
            currentLocale = resolveLocale(locale);
            dotNetRefGlobal = dotNetRef;

            if (!window.google || !google.accounts) {
                if (retryCount < maxRetries) {
                    retryCount++;
                    warn("GIS no cargado. Reintento #" + retryCount);
                    setTimeout(() => init(clientId, dotNetRefGlobal, currentLocale), 150 + retryCount * 50);
                } else {
                    err("GIS no cargó tras reintentos. Activar fallback.");
                    showFallbackMessage();
                }
                return;
            }

            if (initialized && lastClientId === clientId) {
                log("Re-init con mismo clientId -> re-render");
                const hostAgain = document.getElementById("googleSignInBtn");
                if (hostAgain) {
                    forceNextRender = true;
                    firstStableRender(hostAgain);
                }
                return;
            }

            safeDisable();
            revokePrevious();

            google.accounts.id.initialize({
                client_id: clientId,
                callback: (resp) => {
                    try {
                        if (!resp?.credential) {
                            warn("Respuesta sin credential", resp);
                            return;
                        }
                        markEmailFromCredential(resp.credential);
                        dotNetRefGlobal?.invokeMethodAsync("OnGoogleCredential", resp.credential);
                    } catch (e) {
                        err("Error enviando credential .NET", e);
                    }
                },
                auto_select: false,
                ux_mode: "popup",
                hosted_domain: ""
            });

            const host = document.getElementById("googleSignInBtn");
            if (host) {
                firstStableRender(host);
                wireResize(host);
            } else {
                warn("No se encontró #googleSignInBtn");
            }

            initialized = true;
            lastClientId = clientId;
            retryCount = 0;
        } catch (e) {
            err("Error en init()", e);
            showFallbackMessage();
        }
    }

    function cleanup() {
        safeDisable();
        try {
            if (resizeHandler) {
                window.removeEventListener("resize", resizeHandler);
                resizeHandler = null;
            }
            if (viewportResizeHandler && window.visualViewport) {
                window.visualViewport.removeEventListener("resize", viewportResizeHandler);
                viewportResizeHandler = null;
            }
        } catch { }
        try { if (iframeObserver) { iframeObserver.disconnect(); iframeObserver = null; } } catch { }
        clearTimeout(iframeReadyTimer);

        const host = document.getElementById("googleSignInBtn");
        if (host) host.innerHTML = "";

        lastBtnWidth = null;
        shownOnce = false;
        initialized = false;
        forceNextRender = false;
    }

    function signOut() {
        safeDisable();
    }

    function showFallbackMessage() {
        const host = document.getElementById("googleSignInBtn");
        if (host) {
            host.style.visibility = "visible";
            host.classList.add("ready");
            host.innerHTML =
                `<div style="color:#c33;font-size:0.85rem;line-height:1.2">
           Google Sign-In bloqueado por configuración de Edge o extensiones.<br/>
           1) Usa ventana InPrivate ó<br/>
           2) Reduce prevención de seguimiento ó<br/>
           3) <a href="#" id="googleRedirectLogin" style="color:#4f8cff;text-decoration:underline">Iniciar con flujo alternativo</a>
         </div>`;
            const link = document.getElementById("googleRedirectLogin");
            if (link) {
                link.addEventListener("click", (e) => {
                    e.preventDefault();
                    startRedirectFlow();
                });
            }
        }
    }

    function startRedirectFlow() {
        window.location.href = "/api/auth/external/google/redirect-start";
    }

    return { init, signOut, cleanup, forceRefresh };
})();